# AddOSC
OSC support in the viewport for Blender, see: http://www.jpfep.net/pages/addosc/

AddOSC relies on the python module python-osc (by Attwad): 
https://pypi.python.org/pypi/python-osc/
https://github.com/attwad/python-osc

 